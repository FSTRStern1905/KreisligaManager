"""
Statistik-Services des KreisligaManagers.
"""