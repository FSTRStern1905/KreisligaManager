import sqlite3
from pathlib import Path

from PySide6.QtCore import Qt
from PySide6.QtWidgets import (
    QAbstractItemView,
    QHeaderView,
    QLabel,
    QMessageBox,
    QPushButton,
    QTableWidget,
    QTableWidgetItem,
    QVBoxLayout,
    QWidget,
)

from src.services.statistics_service import StatisticsService


DATABASE_PATH = Path("data/database/kreisligamanager.db")


class CompetitionStatisticsTab(QWidget):
    def __init__(self):
        super().__init__()

        self.competition_id = None

        self.setup_ui()
        self.connect_signals()
        self.clear_data()

    def setup_ui(self):
        layout = QVBoxLayout()

        title = QLabel("🏆 Torjäger")
        title.setObjectName("PageTitle")

        self.info_label = QLabel(
            "Kein Wettbewerb ausgewählt"
        )
        self.info_label.setObjectName("InfoLabel")

        self.scorer_table = QTableWidget()
        self.scorer_table.setColumnCount(5)

        self.scorer_table.setHorizontalHeaderLabels(
            [
                "Pos",
                "Spieler",
                "Mannschaft",
                "Position",
                "Tore",
            ]
        )

        self.scorer_table.setEditTriggers(
            QAbstractItemView.NoEditTriggers
        )

        self.scorer_table.setSelectionBehavior(
            QAbstractItemView.SelectRows
        )

        self.scorer_table.setSelectionMode(
            QAbstractItemView.SingleSelection
        )

        self.scorer_table.setAlternatingRowColors(True)
        self.scorer_table.verticalHeader().setVisible(False)

        header = self.scorer_table.horizontalHeader()

        header.setSectionResizeMode(
            0,
            QHeaderView.ResizeToContents,
        )

        header.setSectionResizeMode(
            1,
            QHeaderView.Stretch,
        )

        header.setSectionResizeMode(
            2,
            QHeaderView.Stretch,
        )

        header.setSectionResizeMode(
            3,
            QHeaderView.ResizeToContents,
        )

        header.setSectionResizeMode(
            4,
            QHeaderView.ResizeToContents,
        )

        self.refresh_button = QPushButton(
            "🔄 Torjäger aktualisieren"
        )
        self.refresh_button.setEnabled(False)

        layout.addWidget(title)
        layout.addWidget(self.info_label)
        layout.addWidget(self.scorer_table)
        layout.addWidget(self.refresh_button)

        self.setLayout(layout)

    def connect_signals(self):
        self.refresh_button.clicked.connect(
            self.load_data
        )

    def set_competition(
        self,
        competition_id: int | None,
    ):
        self.competition_id = competition_id

        if competition_id is None:
            self.clear_data()
            return

        self.load_data()

    def load_data(self):
        self.scorer_table.setRowCount(0)

        if self.competition_id is None:
            self.clear_data()
            return

        connection = sqlite3.connect(DATABASE_PATH)

        try:
            service = StatisticsService(connection)

            competition_name = service.get_competition_name(
                self.competition_id
            )

            if competition_name is None:
                self.clear_data()
                return

            scorers = service.get_top_scorers(
                self.competition_id
            )

            scorer_count = service.get_scorer_count(
                self.competition_id
            )

            total_goals = service.get_goal_count(
                self.competition_id
            )

            self.show_scorers(scorers)

            self.info_label.setText(
                f"{competition_name} | "
                f"{scorer_count} Torschützen | "
                f"{total_goals} Tore"
            )

            self.refresh_button.setEnabled(True)

        except (sqlite3.Error, ValueError) as error:
            QMessageBox.critical(
                self,
                "Datenbankfehler",
                (
                    "Die Torjägerliste konnte nicht "
                    f"geladen werden:\n{error}"
                ),
            )

            self.clear_data()

        finally:
            connection.close()

    def show_scorers(
        self,
        scorers: list[dict],
    ):
        self.scorer_table.setRowCount(
            len(scorers)
        )

        current_position = 0
        previous_goals = None

        for row_index, scorer in enumerate(
            scorers
        ):
            if scorer["goals"] != previous_goals:
                current_position = row_index + 1
                previous_goals = scorer["goals"]

            values = [
                current_position,
                scorer["player_name"],
                scorer["team_name"],
                scorer["position"],
                scorer["goals"],
            ]

            for column_index, value in enumerate(
                values
            ):
                item = QTableWidgetItem(str(value))

                if column_index in {
                    0,
                    3,
                    4,
                }:
                    item.setTextAlignment(
                        Qt.AlignCenter
                    )

                item.setData(
                    Qt.UserRole,
                    scorer["player_id"],
                )

                self.scorer_table.setItem(
                    row_index,
                    column_index,
                    item,
                )

    def refresh(self):
        self.load_data()

    def clear_data(self):
        self.scorer_table.setRowCount(0)

        self.info_label.setText(
            "Kein Wettbewerb ausgewählt"
        )

        self.refresh_button.setEnabled(False)