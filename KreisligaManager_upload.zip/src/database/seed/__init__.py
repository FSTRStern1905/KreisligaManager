"""
Seedmodule des KreisligaManagers.
"""