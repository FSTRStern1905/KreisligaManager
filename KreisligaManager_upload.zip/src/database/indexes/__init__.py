"""
Indexmodule des KreisligaManagers.
"""